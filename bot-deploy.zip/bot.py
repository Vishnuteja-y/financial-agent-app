import json
import logging

from botbuilder.core import ActivityHandler, TurnContext, MessageFactory

from search_client import search_financial_data
from cosmos_client import save_turn, format_history_for_prompt
from openai_client import generate_answer

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """
You are a financial analyst AI for TechStarGroup.

Rules:
1. Answer only using the provided retrieved data.
2. Do not invent financial numbers.
3. If the answer is not present in the data, say the data does not contain enough information.
4. Keep the answer clear and business-friendly.
"""


def build_messages(question: str, history: str, documents: list):
    context = json.dumps(documents, indent=2, default=str)

    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"""
Conversation history:
{history}

Retrieved financial data:
{context}

User question:
{question}
""",
        },
    ]


def answer_question(question: str, session_id: str = "web-session"):
    documents = search_financial_data(question, top_k=5)
    history = format_history_for_prompt(session_id)

    messages = build_messages(question, history, documents)
    answer = generate_answer(messages)

    save_turn(session_id, question, answer, documents)

    return {
        "answer": answer,
        "sources": documents,
    }


class FinancialBot(ActivityHandler):
    async def on_message_activity(self, turn_context: TurnContext):
        user_message = turn_context.activity.text
        session_id = turn_context.activity.conversation.id

        try:
            result = answer_question(user_message, session_id)
            await turn_context.send_activity(MessageFactory.text(result["answer"]))

        except Exception as e:
            logger.exception("Bot processing failed")
            await turn_context.send_activity(
                MessageFactory.text("Sorry, I had trouble processing that request.")
            )

    async def on_members_added_activity(self, members_added, turn_context: TurnContext):
        for member in members_added:
            if member.id != turn_context.activity.recipient.id:
                await turn_context.send_activity(
                    MessageFactory.text(
                        "Welcome to Financial AI. Ask me about company revenue, margins, or financial performance."
                    )
                )