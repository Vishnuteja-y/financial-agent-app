from openai import AzureOpenAI
from config import Config

openai_client = AzureOpenAI(
    azure_endpoint=Config.AZURE_OPENAI_ENDPOINT,
    api_key=Config.AZURE_OPENAI_KEY,
    api_version="2024-02-01",
)


def create_embedding(text: str):
    response = openai_client.embeddings.create(
        input=text,
        model=Config.EMBEDDING_MODEL,
    )
    return response.data[0].embedding


def generate_answer(messages):
    response = openai_client.chat.completions.create(
        model=Config.CHAT_MODEL,
        messages=messages,
        temperature=0,
    )
    return response.choices[0].message.content